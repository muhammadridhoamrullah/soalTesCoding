<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\TrxdataSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Trxdatas';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="trxdata-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Trxdata', ['create'], ['class' => 'btn btn-success']) ?>
        <?= Html::a('Export PDF', ['pdf'], ['class' => 'btn btn-danger']) ?>

    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            // 'id_transaksi',
            'waktu_registrasi',
            'nomor_registrasi',
            'nama_pasien',
            'masterjeniskelamin.jenis_kelamin',
            'tanggal_lahir',
            'masterjenisregistrasi.jenis_registrasi',
            'masterjenislayanan.jenis_layanan',
            'masterjenispembayaran.jenis_pembayaran',
            'masterstatusregistrasi.status_registrasi',
            'waktu_mulai_pelayanan',
            'waktu_selesai_pelayanan',
            'masterpetugaspendaftaran.petugas_pendaftaran',
            // 'id_master_jenis_kelamin',
            
            // 'id_master_jenis_pembayaran',
            
            // 'id_master_jenis_registrasi',
            
            // 'id_master_jenis_layanan',
            
            // 'id_master_petugas_pendaftaran',
            
            // 'id_master_status_registrasi',
            
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id_transaksi' => $model->id_transaksi]);
                 }
            ],
        ],
    ]); ?>


</div>
