<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Trxdata */

$this->title = $model->id_transaksi;
$this->params['breadcrumbs'][] = ['label' => 'Trxdatas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="trxdata-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id_transaksi' => $model->id_transaksi], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id_transaksi' => $model->id_transaksi], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id_transaksi',
            'waktu_registrasi',
            'nomor_registrasi',
            'nama_pasien',
            'masterjeniskelamin.jenis_kelamin',
            'tanggal_lahir',
            'masterjenisregistrasi.jenis_registrasi',
            'masterjenislayanan.jenis_layanan',
            'masterjenispembayaran.jenis_pembayaran',
            'masterstatusregistrasi.status_registrasi',
            'waktu_mulai_pelayanan',
            'waktu_selesai_pelayanan',
            'masterpetugaspendaftaran.petugas_pendaftaran',
        ],
    ]) ?>

</div>
