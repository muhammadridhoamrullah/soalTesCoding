<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use kartik\date\DatePicker;

/* @var $this yii\web\View */
/* @var $model app\models\Trxdata */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="trxdata-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'waktu_registrasi')->textInput() ?>

    <?= $form->field($model, 'nomor_registrasi')->textInput() ?>

    <?= $form->field($model, 'nama_pasien')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'tanggal_lahir')->widget(
        \yii\widgets\MaskedInput::class, [
            'mask' => "y-2-1",
            'clientOptions' => [
                'alias' => 'date',
                "placeholder" => "yyyy-mm-dd",
                "separator" => "-"
            ]
        ]
    );

    ?>

    <?= $form->field($model, 'waktu_mulai_pelayanan')->textInput() ?>

    <?= $form->field($model, 'waktu_selesai_pelayanan')->textInput() ?>

    <?php //= $form->field($model, 'id_master_jenis_kelamin')->textInput() ?>

    <?php
    $dataPost=ArrayHelper::map(\app\models\masterjeniskelamin::find()
    ->asArray()->all(), 'id_master_jenis_kelamin', 'jenis_kelamin');
	echo $form->field($model, 'id_master_jenis_kelamin')
        ->dropDownList(
            $dataPost,           
            ['id_master_jenis_kelamin'=>'jenis_kelamin']
        );
    
    ?>


    <?php //= $form->field($model, 'id_master_jenis_pembayaran')->textInput() ?>

    <?php
    $dataPost=ArrayHelper::map(\app\models\masterjenispembayaran::find()
    ->asArray()->all(), 'id_master_jenis_pembayaran', 'jenis_pembayaran');
	echo $form->field($model, 'id_master_jenis_pembayaran')
        ->dropDownList(
            $dataPost,           
            ['id_master_jenis_pembayaran'=>'jenis_pembayaran']
        );
    
    ?>

    <?php //= $form->field($model, 'id_master_jenis_registrasi')->textInput() ?>

    <?php
    $dataPost=ArrayHelper::map(\app\models\masterjenisregistrasi::find()
    ->asArray()->all(), 'id_master_jenis_registrasi', 'jenis_registrasi');
	echo $form->field($model, 'id_master_jenis_registrasi')
        ->dropDownList(
            $dataPost,           
            ['id_master_jenis_registrasi'=>'jenis_registrasi']
        );
    
    ?>

    <?php //= $form->field($model, 'id_master_jenis_layanan')->textInput() ?>

    <?php
    $dataPost=ArrayHelper::map(\app\models\masterjenislayanan::find()
    ->asArray()->all(), 'id_master_jenis_layanan', 'jenis_layanan');
	echo $form->field($model, 'id_master_jenis_layanan')
        ->dropDownList(
            $dataPost,           
            ['id_master_jenis_layanan'=>'jenis_layanan']
        );
    
    ?>

    <?php //= $form->field($model, 'id_master_petugas_pendaftaran')->textInput() ?>

    <?php
    $dataPost=ArrayHelper::map(\app\models\masterpetugaspendaftaran::find()
    ->asArray()->all(), 'id_master_petugas_pendaftaran', 'petugas_pendaftaran');
	echo $form->field($model, 'id_master_petugas_pendaftaran')
        ->dropDownList(
            $dataPost,           
            ['id_master_petugas_pendaftaran'=>'petugas_pendaftaran']
        );
    
    ?>

    <?php //= $form->field($model, 'id_master_status_registrasi')->textInput() ?>

    <?php
    $dataPost=ArrayHelper::map(\app\models\masterstatusregistrasi::find()
    ->asArray()->all(), 'id_master_status_registrasi', 'status_registrasi');
	echo $form->field($model, 'id_master_status_registrasi')
        ->dropDownList(
            $dataPost,           
            ['id_master_status_registrasi'=>'status_registrasi']
        );
    
    ?>

    <br>

    <div class="form-group">
        <?= Html::submitButton('Simpan', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
