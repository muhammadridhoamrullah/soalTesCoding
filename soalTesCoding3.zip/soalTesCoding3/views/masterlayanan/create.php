<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Masterlayanan */

$this->title = 'Create Masterlayanan';
$this->params['breadcrumbs'][] = ['label' => 'Masterlayanans', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="masterlayanan-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
