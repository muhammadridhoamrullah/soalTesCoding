<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Masterpetugaspendaftaran */

$this->title = 'Update Masterpetugaspendaftaran: ' . $model->id_master_petugas_pendaftaran;
$this->params['breadcrumbs'][] = ['label' => 'Masterpetugaspendaftarans', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_master_petugas_pendaftaran, 'url' => ['view', 'id_master_petugas_pendaftaran' => $model->id_master_petugas_pendaftaran]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="masterpetugaspendaftaran-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
