<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "masterjenispembayaran".
 *
 * @property int $id_master_jenis_pembayaran
 * @property string $jenis_pembayaran
 * @property string $kode_jenis_pembayaran
 */
class Masterjenispembayaran extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'masterjenispembayaran';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['jenis_pembayaran', 'kode_jenis_pembayaran'], 'required'],
            [['jenis_pembayaran', 'kode_jenis_pembayaran'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_master_jenis_pembayaran' => 'Id Master Jenis Pembayaran',
            'jenis_pembayaran' => 'Jenis Pembayaran',
            'kode_jenis_pembayaran' => 'Kode Jenis Pembayaran',
        ];
    }

    public function getMasterjenispembayaran()
    {
        // same as above
        return $this->hasOne(Masterjenispembayaran::class(), ['id_master_jenis_pembayaran' => 'id_master_jenis_pembayaran']);
    }

}
