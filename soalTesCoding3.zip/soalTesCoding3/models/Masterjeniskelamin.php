<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "masterjeniskelamin".
 *
 * @property int $id_master_jenis_kelamin
 * @property string $jenis_kelamin
 * @property string $kode_jenis_kelamin
 */
class Masterjeniskelamin extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'masterjeniskelamin';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['jenis_kelamin', 'kode_jenis_kelamin'], 'required'],
            [['jenis_kelamin', 'kode_jenis_kelamin'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_master_jenis_kelamin' => 'Id Master Jenis Kelamin',
            'jenis_kelamin' => 'Jenis Kelamin',
            'kode_jenis_kelamin' => 'Kode Jenis Kelamin',
        ];
    }

    public function getMasterjeniskelamin()
    {
        // same as above
        return $this->hasOne(Masterjeniskelamin::class(), ['id_master_jenis_kelamin' => 'id_master_jenis_kelamin']);
    }

}
