<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Trxdata;

/**
 * TrxdataSearch represents the model behind the search form of `app\models\Trxdata`.
 */
class TrxdataSearch extends Trxdata
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_transaksi', 'nomor_registrasi', 'id_master_jenis_kelamin', 'id_master_jenis_pembayaran', 'id_master_jenis_registrasi', 'id_master_jenis_layanan', 'id_master_petugas_pendaftaran', 'id_master_status_registrasi'], 'integer'],
            [['waktu_registrasi', 'nama_pasien', 'tanggal_lahir', 'waktu_mulai_pelayanan', 'waktu_selesai_pelayanan'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Trxdata::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_transaksi' => $this->id_transaksi,
            'waktu_registrasi' => $this->waktu_registrasi,
            'nomor_registrasi' => $this->nomor_registrasi,
            'tanggal_lahir' => $this->tanggal_lahir,
            'waktu_mulai_pelayanan' => $this->waktu_mulai_pelayanan,
            'waktu_selesai_pelayanan' => $this->waktu_selesai_pelayanan,
            'id_master_jenis_kelamin' => $this->id_master_jenis_kelamin,
            'id_master_jenis_pembayaran' => $this->id_master_jenis_pembayaran,
            'id_master_jenis_registrasi' => $this->id_master_jenis_registrasi,
            'id_master_jenis_layanan' => $this->id_master_jenis_layanan,
            'id_master_petugas_pendaftaran' => $this->id_master_petugas_pendaftaran,
            'id_master_status_registrasi' => $this->id_master_status_registrasi,
        ]);

        $query->andFilterWhere(['like', 'nama_pasien', $this->nama_pasien]);

        return $dataProvider;
    }
}
