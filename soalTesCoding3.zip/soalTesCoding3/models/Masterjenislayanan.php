<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "masterjenislayanan".
 *
 * @property int $id_master_jenis_layanan
 * @property string $jenis_layanan
 * @property string $kode_layanan
 */
class Masterjenislayanan extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'masterjenislayanan';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['jenis_layanan', 'kode_layanan'], 'required'],
            [['jenis_layanan', 'kode_layanan'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_master_jenis_layanan' => 'Id Master Jenis Layanan',
            'jenis_layanan' => 'Jenis Layanan',
            'kode_layanan' => 'Kode Layanan',
        ];
    }
}
