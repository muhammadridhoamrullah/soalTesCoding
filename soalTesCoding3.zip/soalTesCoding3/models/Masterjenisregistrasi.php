<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "masterjenisregistrasi".
 *
 * @property int $id_master_jenis_registrasi
 * @property string $jenis_registrasi
 * @property string $kode_jenis_registrasi
 */
class Masterjenisregistrasi extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'masterjenisregistrasi';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['jenis_registrasi', 'kode_jenis_registrasi'], 'required'],
            [['jenis_registrasi', 'kode_jenis_registrasi'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_master_jenis_registrasi' => 'Id Master Jenis Registrasi',
            'jenis_registrasi' => 'Jenis Registrasi',
            'kode_jenis_registrasi' => 'Kode Jenis Registrasi',
        ];
    }
}
