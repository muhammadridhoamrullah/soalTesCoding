<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "masterpetugaspendaftaran".
 *
 * @property int $id_master_petugas_pendaftaran
 * @property string $petugas_pendaftaran
 * @property string $kode_petugas_pendaftaran
 */
class Masterpetugaspendaftaran extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'masterpetugaspendaftaran';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['petugas_pendaftaran', 'kode_petugas_pendaftaran'], 'required'],
            [['petugas_pendaftaran', 'kode_petugas_pendaftaran'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_master_petugas_pendaftaran' => 'Id Master Petugas Pendaftaran',
            'petugas_pendaftaran' => 'Petugas Pendaftaran',
            'kode_petugas_pendaftaran' => 'Kode Petugas Pendaftaran',
        ];
    }
}
