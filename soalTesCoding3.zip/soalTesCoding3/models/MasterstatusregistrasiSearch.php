<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Masterstatusregistrasi;

/**
 * MasterstatusregistrasiSearch represents the model behind the search form of `app\models\Masterstatusregistrasi`.
 */
class MasterstatusregistrasiSearch extends Masterstatusregistrasi
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_master_status_registrasi'], 'integer'],
            [['status_registrasi', 'kode_status_registrasi'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Masterstatusregistrasi::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_master_status_registrasi' => $this->id_master_status_registrasi,
        ]);

        $query->andFilterWhere(['like', 'status_registrasi', $this->status_registrasi])
            ->andFilterWhere(['like', 'kode_status_registrasi', $this->kode_status_registrasi]);

        return $dataProvider;
    }
}
