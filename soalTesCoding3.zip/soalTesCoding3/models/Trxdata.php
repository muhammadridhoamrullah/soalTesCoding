<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "trxdata".
 *
 * @property int $id_transaksi
 * @property string $waktu_registrasi
 * @property int $nomor_registrasi
 * @property string $nama_pasien
 * @property string $tanggal_lahir
 * @property string $waktu_mulai_pelayanan
 * @property string $waktu_selesai_pelayanan
 * @property int $id_master_jenis_kelamin
 * @property int $id_master_jenis_pembayaran
 * @property int $id_master_jenis_registrasi
 * @property int $id_master_jenis_layanan
 * @property int $id_master_petugas_pendaftaran
 * @property int $id_master_status_registrasi
 */
class Trxdata extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'trxdata';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['waktu_registrasi', 'tanggal_lahir', 'waktu_mulai_pelayanan', 'waktu_selesai_pelayanan'], 'safe'],
            [['nomor_registrasi', 'nama_pasien', 'tanggal_lahir', 'id_master_jenis_kelamin', 'id_master_jenis_pembayaran', 'id_master_jenis_registrasi', 'id_master_jenis_layanan', 'id_master_petugas_pendaftaran', 'id_master_status_registrasi'], 'required'],
            [['nomor_registrasi', 'id_master_jenis_kelamin', 'id_master_jenis_pembayaran', 'id_master_jenis_registrasi', 'id_master_jenis_layanan', 'id_master_petugas_pendaftaran', 'id_master_status_registrasi'], 'integer'],
            [['nama_pasien'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_transaksi' => 'Id Transaksi',
            'waktu_registrasi' => 'Waktu Registrasi',
            'nomor_registrasi' => 'Nomor Registrasi',
            'nama_pasien' => 'Nama Pasien',
            'tanggal_lahir' => 'Tanggal Lahir',
            'waktu_mulai_pelayanan' => 'Waktu Mulai Pelayanan',
            'waktu_selesai_pelayanan' => 'Waktu Selesai Pelayanan',
            'id_master_jenis_kelamin' => 'Id Master Jenis Kelamin',
            'id_master_jenis_pembayaran' => 'Id Master Jenis Pembayaran',
            'id_master_jenis_registrasi' => 'Id Master Jenis Registrasi',
            'id_master_jenis_layanan' => 'Id Master Jenis Layanan',
            'id_master_petugas_pendaftaran' => 'Id Master Petugas Pendaftaran',
            'id_master_status_registrasi' => 'Id Master Status Registrasi',
        ];
    }

    public function getMasterjeniskelamin()
    {
        return $this->hasOne(Masterjeniskelamin::class, ['id_master_jenis_kelamin' => 'id_master_jenis_kelamin']);
    }

    public function getMasterjenispembayaran()
    {
        // same as above
        return $this->hasOne(Masterjenispembayaran::class, ['id_master_jenis_pembayaran' => 'id_master_jenis_pembayaran']);
    }

    public function getMasterjenisregistrasi()
    {
        // same as above
        return $this->hasOne(Masterjenisregistrasi::class, ['id_master_jenis_registrasi' => 'id_master_jenis_registrasi']);
    }

    public function getMasterjenislayanan()
    {
        // same as above
        return $this->hasOne(Masterjenislayanan::class, ['id_master_jenis_layanan' => 'id_master_jenis_layanan']);
    }
    
    public function getMasterpetugaspendaftaran()
    {
        // same as above
        return $this->hasOne(Masterpetugaspendaftaran::class, ['id_master_petugas_pendaftaran' => 'id_master_petugas_pendaftaran']);
    }

    public function getMasterstatusregistrasi()
    {
        // same as above
        return $this->hasOne(Masterstatusregistrasi::class, ['id_master_status_registrasi' => 'id_master_status_registrasi']);
    }

}
