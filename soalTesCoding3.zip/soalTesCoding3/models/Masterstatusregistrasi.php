<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "masterstatusregistrasi".
 *
 * @property int $id_master_status_registrasi
 * @property string $status_registrasi
 * @property string $kode_status_registrasi
 */
class Masterstatusregistrasi extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'masterstatusregistrasi';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['status_registrasi', 'kode_status_registrasi'], 'required'],
            [['status_registrasi', 'kode_status_registrasi'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_master_status_registrasi' => 'Id Master Status Registrasi',
            'status_registrasi' => 'Status Registrasi',
            'kode_status_registrasi' => 'Kode Status Registrasi',
        ];
    }

    public function getMasterstatusregistrasi()
    {
        // same as above
        return $this->hasOne(Masterstatusregistrasi::class, ['id_master_status_registrasi' => 'id_master_status_registrasi']);
    }
}
