-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2022 at 04:28 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `soaltescoding3`
--

-- --------------------------------------------------------

--
-- Table structure for table `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jabatan` int(11) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `kode_jabatan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `jabatan`, `kode_jabatan`) VALUES
(1, 'KEPALA', 'KEP'),
(2, 'WAKIL KEPALA', 'WKL'),
(3, 'SUPERVISOR', 'SPV');

-- --------------------------------------------------------

--
-- Table structure for table `masterjeniskelamin`
--

CREATE TABLE `masterjeniskelamin` (
  `id_master_jenis_kelamin` int(11) NOT NULL,
  `jenis_kelamin` varchar(50) NOT NULL,
  `kode_jenis_kelamin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `masterjeniskelamin`
--

INSERT INTO `masterjeniskelamin` (`id_master_jenis_kelamin`, `jenis_kelamin`, `kode_jenis_kelamin`) VALUES
(1, 'Laki-Laki', 'LK'),
(2, 'Perempuan', 'PR');

-- --------------------------------------------------------

--
-- Table structure for table `masterjenislayanan`
--

CREATE TABLE `masterjenislayanan` (
  `id_master_jenis_layanan` int(11) NOT NULL,
  `jenis_layanan` varchar(50) NOT NULL,
  `kode_layanan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `masterjenislayanan`
--

INSERT INTO `masterjenislayanan` (`id_master_jenis_layanan`, `jenis_layanan`, `kode_layanan`) VALUES
(1, 'Poliklinik Umum', 'POLUM'),
(2, 'Poliklinik Gigi', 'POLGI'),
(3, 'Poliklinik Obgyn', 'POLGYN'),
(4, 'UGD', 'UGD'),
(5, 'Kelas 1', 'KLS1'),
(6, 'Poliklinik Mata', 'POLMATA'),
(7, 'Kelas 2', 'KLS2');

-- --------------------------------------------------------

--
-- Table structure for table `masterjenispembayaran`
--

CREATE TABLE `masterjenispembayaran` (
  `id_master_jenis_pembayaran` int(11) NOT NULL,
  `jenis_pembayaran` varchar(50) NOT NULL,
  `kode_jenis_pembayaran` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `masterjenispembayaran`
--

INSERT INTO `masterjenispembayaran` (`id_master_jenis_pembayaran`, `jenis_pembayaran`, `kode_jenis_pembayaran`) VALUES
(1, 'Umum', 'UM'),
(2, 'BPJS Kesehatan', 'BPJS'),
(3, 'Mandiri Inhealth', 'MANDIRI'),
(4, 'BNI Life', 'BNIL');

-- --------------------------------------------------------

--
-- Table structure for table `masterjenisregistrasi`
--

CREATE TABLE `masterjenisregistrasi` (
  `id_master_jenis_registrasi` int(11) NOT NULL,
  `jenis_registrasi` varchar(50) NOT NULL,
  `kode_jenis_registrasi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `masterjenisregistrasi`
--

INSERT INTO `masterjenisregistrasi` (`id_master_jenis_registrasi`, `jenis_registrasi`, `kode_jenis_registrasi`) VALUES
(1, 'Rawat Jalan', 'RJL'),
(2, 'UGD', 'UGD'),
(3, 'Rawat Inap', 'RIN');

-- --------------------------------------------------------

--
-- Table structure for table `masterlayanan`
--

CREATE TABLE `masterlayanan` (
  `id_master_layanan` int(11) NOT NULL,
  `jenis_layanan` varchar(50) NOT NULL,
  `kode_layanan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `masterlayanan`
--

INSERT INTO `masterlayanan` (`id_master_layanan`, `jenis_layanan`, `kode_layanan`) VALUES
(1, 'Poliklinik Umum', 'POLUM'),
(2, 'Poliklinik Gigi', 'POLGI'),
(3, 'Poliklinik Obgyn', 'POLGYN'),
(4, 'UGD', 'UGD'),
(5, 'Kelas 1', 'KLS1'),
(6, 'Poliklinik Mata', 'POLMATA'),
(7, 'Kelas 2', 'KLS2');

-- --------------------------------------------------------

--
-- Table structure for table `masterpetugaspendaftaran`
--

CREATE TABLE `masterpetugaspendaftaran` (
  `id_master_petugas_pendaftaran` int(11) NOT NULL,
  `petugas_pendaftaran` varchar(50) NOT NULL,
  `kode_petugas_pendaftaran` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `masterpetugaspendaftaran`
--

INSERT INTO `masterpetugaspendaftaran` (`id_master_petugas_pendaftaran`, `petugas_pendaftaran`, `kode_petugas_pendaftaran`) VALUES
(1, 'Safitri Jayanti', 'SAFJYNT'),
(2, 'Ahmad Sandi', 'AHMDSND'),
(3, 'Cici Utami', 'CICIU'),
(4, 'Putri Aisha', 'PUTRASH');

-- --------------------------------------------------------

--
-- Table structure for table `masterstatusregistrasi`
--

CREATE TABLE `masterstatusregistrasi` (
  `id_master_status_registrasi` int(11) NOT NULL,
  `status_registrasi` varchar(50) NOT NULL,
  `kode_status_registrasi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `masterstatusregistrasi`
--

INSERT INTO `masterstatusregistrasi` (`id_master_status_registrasi`, `status_registrasi`, `kode_status_registrasi`) VALUES
(1, 'Tutup Kunjungan', 'TTP'),
(2, 'Aktif', 'AKTF');

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `id_pegawai` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `id_jabatan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nama`, `nip`, `alamat`, `id_jabatan`) VALUES
(1, 'Muhammad Ridho Amrullah', '121', 'AS', 1),
(2, 'Olivia', '343', 'nn', 3);

-- --------------------------------------------------------

--
-- Table structure for table `trxdata`
--

CREATE TABLE `trxdata` (
  `id_transaksi` int(11) NOT NULL,
  `waktu_registrasi` timestamp NOT NULL DEFAULT current_timestamp(),
  `nomor_registrasi` int(50) NOT NULL,
  `nama_pasien` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `waktu_mulai_pelayanan` timestamp NOT NULL DEFAULT current_timestamp(),
  `waktu_selesai_pelayanan` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_master_jenis_kelamin` int(11) NOT NULL,
  `id_master_jenis_pembayaran` int(11) NOT NULL,
  `id_master_jenis_registrasi` int(11) NOT NULL,
  `id_master_jenis_layanan` int(11) NOT NULL,
  `id_master_petugas_pendaftaran` int(11) NOT NULL,
  `id_master_status_registrasi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trxdata`
--

INSERT INTO `trxdata` (`id_transaksi`, `waktu_registrasi`, `nomor_registrasi`, `nama_pasien`, `tanggal_lahir`, `waktu_mulai_pelayanan`, `waktu_selesai_pelayanan`, `id_master_jenis_kelamin`, `id_master_jenis_pembayaran`, `id_master_jenis_registrasi`, `id_master_jenis_layanan`, `id_master_petugas_pendaftaran`, `id_master_status_registrasi`) VALUES
(1, '2022-08-23 09:49:20', 220923, 'Ridho', '2022-08-04', '2022-08-23 09:49:20', '2022-08-23 09:49:20', 1, 1, 2, 1, 2, 1),
(2, '0000-00-00 00:00:00', 12121212, 'Muhammad Ridho', '2018-09-09', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, 2, 2, 2, 2, 2),
(3, '0000-00-00 00:00:00', 56, 'gg', '2018-09-08', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 2, 1, 2, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indexes for table `masterjeniskelamin`
--
ALTER TABLE `masterjeniskelamin`
  ADD PRIMARY KEY (`id_master_jenis_kelamin`);

--
-- Indexes for table `masterjenislayanan`
--
ALTER TABLE `masterjenislayanan`
  ADD PRIMARY KEY (`id_master_jenis_layanan`);

--
-- Indexes for table `masterjenispembayaran`
--
ALTER TABLE `masterjenispembayaran`
  ADD PRIMARY KEY (`id_master_jenis_pembayaran`);

--
-- Indexes for table `masterjenisregistrasi`
--
ALTER TABLE `masterjenisregistrasi`
  ADD PRIMARY KEY (`id_master_jenis_registrasi`);

--
-- Indexes for table `masterlayanan`
--
ALTER TABLE `masterlayanan`
  ADD PRIMARY KEY (`id_master_layanan`);

--
-- Indexes for table `masterpetugaspendaftaran`
--
ALTER TABLE `masterpetugaspendaftaran`
  ADD PRIMARY KEY (`id_master_petugas_pendaftaran`);

--
-- Indexes for table `masterstatusregistrasi`
--
ALTER TABLE `masterstatusregistrasi`
  ADD PRIMARY KEY (`id_master_status_registrasi`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `trxdata`
--
ALTER TABLE `trxdata`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `id_jabatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `masterjeniskelamin`
--
ALTER TABLE `masterjeniskelamin`
  MODIFY `id_master_jenis_kelamin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `masterjenislayanan`
--
ALTER TABLE `masterjenislayanan`
  MODIFY `id_master_jenis_layanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `masterjenispembayaran`
--
ALTER TABLE `masterjenispembayaran`
  MODIFY `id_master_jenis_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `masterjenisregistrasi`
--
ALTER TABLE `masterjenisregistrasi`
  MODIFY `id_master_jenis_registrasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `masterlayanan`
--
ALTER TABLE `masterlayanan`
  MODIFY `id_master_layanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `masterpetugaspendaftaran`
--
ALTER TABLE `masterpetugaspendaftaran`
  MODIFY `id_master_petugas_pendaftaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `masterstatusregistrasi`
--
ALTER TABLE `masterstatusregistrasi`
  MODIFY `id_master_status_registrasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trxdata`
--
ALTER TABLE `trxdata`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
