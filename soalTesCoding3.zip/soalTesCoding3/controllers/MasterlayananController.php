<?php

namespace app\controllers;

use app\models\Masterlayanan;
use app\models\MasterlayananSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * MasterlayananController implements the CRUD actions for Masterlayanan model.
 */
class MasterlayananController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Masterlayanan models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new MasterlayananSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Masterlayanan model.
     * @param int $id_master_layanan Id Master Layanan
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id_master_layanan)
    {
        return $this->render('view', [
            'model' => $this->findModel($id_master_layanan),
        ]);
    }

    /**
     * Creates a new Masterlayanan model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Masterlayanan();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id_master_layanan' => $model->id_master_layanan]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Masterlayanan model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id_master_layanan Id Master Layanan
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id_master_layanan)
    {
        $model = $this->findModel($id_master_layanan);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_master_layanan' => $model->id_master_layanan]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Masterlayanan model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id_master_layanan Id Master Layanan
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id_master_layanan)
    {
        $this->findModel($id_master_layanan)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Masterlayanan model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $id_master_layanan Id Master Layanan
     * @return Masterlayanan the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id_master_layanan)
    {
        if (($model = Masterlayanan::findOne(['id_master_layanan' => $id_master_layanan])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
