<?php

namespace app\controllers;

use app\models\Masterpetugaspendaftaran;
use app\models\MasterpetugaspendaftaranSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * MasterpetugaspendaftaranController implements the CRUD actions for Masterpetugaspendaftaran model.
 */
class MasterpetugaspendaftaranController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Masterpetugaspendaftaran models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new MasterpetugaspendaftaranSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Masterpetugaspendaftaran model.
     * @param int $id_master_petugas_pendaftaran Id Master Petugas Pendaftaran
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id_master_petugas_pendaftaran)
    {
        return $this->render('view', [
            'model' => $this->findModel($id_master_petugas_pendaftaran),
        ]);
    }

    /**
     * Creates a new Masterpetugaspendaftaran model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Masterpetugaspendaftaran();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id_master_petugas_pendaftaran' => $model->id_master_petugas_pendaftaran]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Masterpetugaspendaftaran model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id_master_petugas_pendaftaran Id Master Petugas Pendaftaran
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id_master_petugas_pendaftaran)
    {
        $model = $this->findModel($id_master_petugas_pendaftaran);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_master_petugas_pendaftaran' => $model->id_master_petugas_pendaftaran]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Masterpetugaspendaftaran model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id_master_petugas_pendaftaran Id Master Petugas Pendaftaran
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id_master_petugas_pendaftaran)
    {
        $this->findModel($id_master_petugas_pendaftaran)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Masterpetugaspendaftaran model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $id_master_petugas_pendaftaran Id Master Petugas Pendaftaran
     * @return Masterpetugaspendaftaran the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id_master_petugas_pendaftaran)
    {
        if (($model = Masterpetugaspendaftaran::findOne(['id_master_petugas_pendaftaran' => $id_master_petugas_pendaftaran])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
