<?php

namespace app\controllers;

use app\models\Masterjenislayanan;
use app\models\MasterjenislayananSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * MasterjenislayananController implements the CRUD actions for Masterjenislayanan model.
 */
class MasterjenislayananController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Masterjenislayanan models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new MasterjenislayananSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Masterjenislayanan model.
     * @param int $id_master_jenis_layanan Id Master Jenis Layanan
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id_master_jenis_layanan)
    {
        return $this->render('view', [
            'model' => $this->findModel($id_master_jenis_layanan),
        ]);
    }

    /**
     * Creates a new Masterjenislayanan model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Masterjenislayanan();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id_master_jenis_layanan' => $model->id_master_jenis_layanan]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Masterjenislayanan model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id_master_jenis_layanan Id Master Jenis Layanan
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id_master_jenis_layanan)
    {
        $model = $this->findModel($id_master_jenis_layanan);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_master_jenis_layanan' => $model->id_master_jenis_layanan]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Masterjenislayanan model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id_master_jenis_layanan Id Master Jenis Layanan
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id_master_jenis_layanan)
    {
        $this->findModel($id_master_jenis_layanan)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Masterjenislayanan model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $id_master_jenis_layanan Id Master Jenis Layanan
     * @return Masterjenislayanan the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id_master_jenis_layanan)
    {
        if (($model = Masterjenislayanan::findOne(['id_master_jenis_layanan' => $id_master_jenis_layanan])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
