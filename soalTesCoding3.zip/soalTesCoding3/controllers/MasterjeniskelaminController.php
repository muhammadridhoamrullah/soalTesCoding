<?php

namespace app\controllers;

use app\models\Masterjeniskelamin;
use app\models\MasterjeniskelaminSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * MasterjeniskelaminController implements the CRUD actions for Masterjeniskelamin model.
 */
class MasterjeniskelaminController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Masterjeniskelamin models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new MasterjeniskelaminSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Masterjeniskelamin model.
     * @param int $id_master_jenis_kelamin Id Master Jenis Kelamin
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id_master_jenis_kelamin)
    {
        return $this->render('view', [
            'model' => $this->findModel($id_master_jenis_kelamin),
        ]);
    }

    /**
     * Creates a new Masterjeniskelamin model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Masterjeniskelamin();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id_master_jenis_kelamin' => $model->id_master_jenis_kelamin]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Masterjeniskelamin model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id_master_jenis_kelamin Id Master Jenis Kelamin
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id_master_jenis_kelamin)
    {
        $model = $this->findModel($id_master_jenis_kelamin);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_master_jenis_kelamin' => $model->id_master_jenis_kelamin]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Masterjeniskelamin model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id_master_jenis_kelamin Id Master Jenis Kelamin
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id_master_jenis_kelamin)
    {
        $this->findModel($id_master_jenis_kelamin)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Masterjeniskelamin model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $id_master_jenis_kelamin Id Master Jenis Kelamin
     * @return Masterjeniskelamin the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id_master_jenis_kelamin)
    {
        if (($model = Masterjeniskelamin::findOne(['id_master_jenis_kelamin' => $id_master_jenis_kelamin])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
